/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebaxml;
import java.sql.*;
/**
 *
 * @author ASUS
 */
public class PruebaXML {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // Conectar a la base de datos PostgreSQL
            Class.forName("org.postgresql.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "andres2003");

            // Llamada al procedimiento "guardar_producto"
            guardarProducto(conexion, "<producto><nombre>MAZDA</nombre><precio>250000</precio></producto>");

            // Llamada al procedimiento "actualizar_producto"
            actualizarProducto(conexion, 1, "<producto><nombre>MAZDA 3</nombre><precio>250000</precio></producto>");

            // Llamada a la función "obtener_precio_producto"
            double precioProducto = obtenerPrecioProducto(conexion, 1);
            System.out.println("Precio del producto con ID 1: " + precioProducto);

            // Llamada a la función "obtener_precio_con_nombre_producto"
            double precioProductoPorNombre = obtenerPrecioConNombreProducto(conexion, "MAZDA CX30");
            System.out.println("Precio del producto con nombre 'MAZDA CX30': " + precioProductoPorNombre);

            // Cerrar la conexión
            conexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Procedimiento para guardar un producto
    public static void guardarProducto(Connection conexion, String xmlProducto) throws SQLException {
        String callSQL = "{ call guardar_producto(?) }";
        try (CallableStatement stmt = conexion.prepareCall(callSQL)) {
            stmt.setString(1, xmlProducto);
            stmt.execute();
            System.out.println("Producto guardado exitosamente.");
        }
    }

    // Procedimiento para actualizar un producto
    public static void actualizarProducto(Connection conexion, int productoId, String xmlProducto) throws SQLException {
        String callSQL = "{ call actualizar_producto(?, ?) }";
        try (CallableStatement stmt = conexion.prepareCall(callSQL)) {
            stmt.setInt(1, productoId);
            stmt.setString(2, xmlProducto);
            stmt.execute();
            System.out.println("Producto actualizado exitosamente.");
        }
    }

    // Función para obtener el precio de un producto por ID
    public static double obtenerPrecioProducto(Connection conexion, int productoId) throws SQLException {
        String callSQL = "select obtener_precio_producto(?)";
        try (PreparedStatement stmt = conexion.prepareStatement(callSQL)) {
            stmt.setInt(1, productoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }

    // Función para obtener el precio de un producto por nombre
    public static double obtenerPrecioConNombreProducto(Connection conexion, String nombreProducto) throws SQLException {
        String callSQL = "select obtener_precio_con_nombre_producto(?)";
        try (PreparedStatement stmt = conexion.prepareStatement(callSQL)) {
            stmt.setString(1, nombreProducto);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }
    
}
