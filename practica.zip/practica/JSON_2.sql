create or replace procedure agregar_producto(
	p_nombre VARCHAR,
	p_detalles JSONB
);