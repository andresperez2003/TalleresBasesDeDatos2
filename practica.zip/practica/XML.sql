-- Creación de la tabla productos
create table if not exists productos (
    id serial primary key,                 -- Columna para el ID del producto
    descripcion xml,                       -- Columna para el XML de la descripción del producto
    nombre varchar(100),                   -- Nombre del producto, solo para fines de búsqueda
    precio numeric                         -- Precio del producto
);

-- Inserción de datos de ejemplo para pruebas
insert into productos (descripcion, nombre, precio)
values (
    xmlparse(document '<producto><nombre>MAZDA CX30</nombre><precio>300000</precio></producto>'), 
    'MAZDA CX30', 
    300000
), (
    xmlparse(document '<producto><nombre>MAZDA 3</nombre><precio>250000</precio></producto>'), 
    'MAZDA 3', 
    250000
);

select 
    unnest(xpath('//nombre/text()', descripcion))::text as nombre,
    unnest(xpath('//precio/text()', descripcion))::text as precio
from productos;


-- Creación o reemplazo del procedimiento guardar_producto
create or replace procedure guardar_producto(p_producto varchar)
language plpgsql as $$
begin
    insert into productos (id, descripcion) 
    values (default, xmlparse(document p_producto));  -- Convierte varchar a XML
end;
$$;


call guardar_producto('<producto><nombre>MAZDA</nombre><precio>250000</precio></producto>');

-- Creación o reemplazo del procedimiento actualizar_producto
create or replace procedure actualizar_producto(p_producto_id integer, p_producto varchar)
language plpgsql as $$
begin
    update productos 
    set descripcion = xmlparse(document p_producto) 
    where id = p_producto_id;
end;
$$;


-- Llamada al procedimiento
call actualizar_producto(4, '<producto><nombre>MAZDA 3</nombre><precio>250000</precio></producto>');

-- Función para obtener el precio del producto por ID
create or replace function obtener_precio_producto(producto_id integer)
returns numeric 
language plpgsql as $$
declare 
    v_precio numeric;
begin 
    select unnest(xpath('//precio/text()', descripcion))::text::numeric 
    into v_precio 
    from productos 
    where id = producto_id;
    return v_precio;
end;
$$;

-- Llamada a la función para obtener el precio del producto
select obtener_precio_producto(1);

-- Selección de productos usando xmltable
select p.nombre, p.precio
from productos,
xmltable('/producto' passing descripcion 
         columns nombre text path 'nombre', 
                 precio numeric path 'precio') as p 
where p.nombre = 'MAZDA CX30';

-- Función para obtener el precio del producto por nombre
create or replace function obtener_precio_con_nombre_producto(p_nombre varchar)
returns numeric 
language plpgsql as $$
declare 
    v_precio numeric;
begin 
    select p.precio into v_precio
    from productos,
    xmltable('/producto' passing descripcion 
             columns nombre text path 'nombre', 
                     precio numeric path 'precio') as p 
    where p.nombre = p_nombre;
    return v_precio;
end;
$$;

-- Llamada a la función para obtener el precio usando el nombre
select obtener_precio_con_nombre_producto('MAZDA CX30');

