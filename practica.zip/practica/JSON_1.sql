create table productos (
	id serial primary key,
	nombre varchar(100),
	detalles JSONB
);

insert into productos(nombre, detalles)
values
('Laptop', '{"marca":"Dell", "modelo":"XPS 13", "precio":1200, "especificaciones":{"ram":"16GB" }}'),
('Smartphone', '{"marca":"Samsung", "modelo":"S23" , "precio":2000, "especificaciones":{"ram":"4GB" }}');



select 
nombre, 
detalles ->> 'marca' as marca,
detalles ->> 'precio' as precio
from productos;


select * from productos
where (detalles ->> 'precio')::numeric < 1500;

select * from productos 
where detalles ->> 'marca' = 'Dell';

select * from productos
where detalles ->'especificaciones' ->> 'ram' = '4GB'

update productos 
set detalles = jsonb_set(detalles, '{especificaciones,ram}', '"8GB"') 
where nombre = 'Smartphone';