create table productos (
	id serial primary key,
	nombre varchar(50),
	categoria varchar(50),
	precio numeric

);


insert into productos (nombre, categoria, precio) values
('Laptop', 'Electrónica', 1200),
('Smartphone', 'Electrónica', 800),
('Bicicleta', 'Deportes', 300),
('Raqueta', 'Deportes', 50),
('Televisor', 'Electrónica', 600),
('Libro', 'Libros', 20);



create or replace function obtener_productos_con_descuento(p_min_precio numeric, p_descuento numeric)
returns table(nombre varchar, categoria varchar, precio_original numeric, precio_descuento numeric) as $$
begin
	return query
	select p.nombre, p.categoria, p.precio as precio_original, p.precio * (1-p_descuento/100) as precio_descuento
	from productos p
	where p.precio > p_min_precio;
end;
$$ language plpgsql;


select * from obtener_productos_con_descuento(100,10);