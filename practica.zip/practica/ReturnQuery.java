/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica;

import java.sql.*;
import java.sql.DriverManager;

/**
 *
 * @author ASUS
 */
public class Practica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            try {
            Class.forName("org.postgresql.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "andres2003");

            // Ejecutar la función con SELECT en lugar de CALL
            PreparedStatement stmt = conexion.prepareStatement("SELECT * FROM returnquery.obtener_empleados_departamento(?)");
            stmt.setString(1, "Ventas");  // Par metro para el departamento

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String departamento = rs.getString("departamento");
                double salario_mensual = rs.getDouble("salario_mensual");
                double salario_anual = rs.getDouble("salario_anual");

                System.out.println("id: " + id + ", nombre: " + nombre + ", departamento: " + departamento + ", salario mensual: " + salario_mensual + ", salario anual: " + salario_anual);
            }

            rs.close();
            stmt.close();
            conexion.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
}
