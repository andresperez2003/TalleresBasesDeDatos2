CREATE TABLE estudiantes (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50),
    promedio NUMERIC
);

INSERT INTO estudiantes (nombre, promedio) VALUES
('Carlos', 60),
('Ana', 70),
('Laura', 85),
('Pedro', 50),
('Sofia', 90);

create or replace procedure mejorar_calificaciones(p_min_promedio numeric)
language plpgsql
as $$
declare 
	v_cursor cursor for select id,nombre,promedio from estudiantes where promedio < p_min_promedio;
	v_incremento numeric;
	est_id int;
	nombre_estudiante varchar(50);
	promedio_estudiante numeric;
begin
	open v_cursor;
	loop
		fetch v_cursor into est_id, nombre_estudiante, promedio_estudiante;
	exit when not found;
	
	v_incremento:= promedio_estudiante *0.10;
	
	update estudiantes set promedio = promedio_estudiante + v_incremento
	where id = est_id;
	end loop;
	close v_cursor;
end;
$$;

SELECT * FROM estudiantes;

CALL mejorar_calificaciones(75);
	
SELECT * FROM estudiantes;
