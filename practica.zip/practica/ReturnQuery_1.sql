CREATE TABLE empleados (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50),
    cargo VARCHAR(50),
    salario NUMERIC
);

create or replace function obtener_empleados_con_salario_mayor(p_min_salario NUMERIC)
returns table(id INT, nombre varchar, cargo varchar, salario numeric) as $$

begin 
	return query
	select p.id,p.nombre,p.cargo,p.salario
	from empleados p
	where p.salario > p_min_salario;
end;
$$ language plpgsql;



insert into empleados(nombre,cargo,salario) values('Andres','Administrador',5000);
insert into empleados(nombre,cargo,salario) values('Juan','Empleado',2500);
insert into empleados(nombre,cargo,salario) values('Angie','Juez',3001);
insert into empleados(nombre,cargo,salario) values('Miguel','No hace nada',4500);
insert into empleados(nombre,cargo,salario) values('Ana','Investigadora',3500);


select * from obtener_empleados_con_salario_mayor(3000);
